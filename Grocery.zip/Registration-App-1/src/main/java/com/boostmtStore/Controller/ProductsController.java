package com.boostmtStore.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.boostmtStore.Services.ProductRepository;
import com.boostmtStore.Services.ProductService;
import com.boostmtStore.models.Product;
import com.boostmtStore.models.ProductDto;

import jakarta.persistence.criteria.Path;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/products")
public class ProductsController {
	@Autowired
	private ProductRepository repo;

	@GetMapping({ "", "/" })
	public String listProducts(Model model) {
		List<Product> products = repo.findAll();
		model.addAttribute("products", products);
		return "products/index";
	}

	@GetMapping("/create")
	public String showCreatePage(Model model) {
		ProductDto prdtDto = new ProductDto();
		model.addAttribute("prdtDto", prdtDto);
		return "products/creatProduct";
	}
	@Autowired
	private ProductService productService;
	@PostMapping("/create")
	public String createProduct(
	        @Valid @ModelAttribute("prdtDto") ProductDto prdtDto,
	        BindingResult result, Model model) {
	    if (prdtDto.getImageFile().isEmpty()) {
	        result.addError(new FieldError("prdtDto", "imageFile", "The image File is required"));
	    }
	    if (result.hasErrors()) {
	        return "products/createProduct";
	    }

	    // Convert ProductDto to Product entity
	    Product product = new Product();
	    product.setName(prdtDto.getName());
	    product.setBrands(prdtDto.getBrands());
	    product.setCategory(prdtDto.getCategory());
	    product.setPrice(prdtDto.getPrice());
	    product.setDescription(prdtDto.getDescription());
	    product.setCreatedAt(LocalDateTime.now());

	    // Handle the image file
	    MultipartFile imageFile = prdtDto.getImageFile();
	    if (!imageFile.isEmpty()) {
	        String fileName = imageFile.getOriginalFilename();
	        if (fileName != null && !fileName.isEmpty()) {
	            product.setImageFileName(fileName);

	            java.nio.file.Path uploadPath = Paths.get("public/image");
	            try {
	                if (!Files.exists(uploadPath)) {
	                    Files.createDirectories(uploadPath);
	                }
	                java.nio.file.Path filePath = uploadPath.resolve(fileName);
	                Files.copy(imageFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
	            } catch (IOException e) {
	                e.printStackTrace();
	                result.addError(new FieldError("prdtDto", "imageFile", "Failed to save the image file"));
	                return "products/createProduct";
	            }
	        } else {
	            result.addError(new FieldError("prdtDto", "imageFile", "Invalid file name"));
	            return "products/createProduct";
	        }
	    }

	    // Save the product entity using the service layer
	    productService.saveProduct(product);

	    return "redirect:/products";
	}
	@PostMapping("/delete/{id}")
	public String deleteProduct(@PathVariable("id") Integer id) {
	    productService.deleteProductById(id);
	    return "redirect:/products";
	}
	
	@GetMapping("/edit/{id}")
	public String showEditPage(@PathVariable("id") Integer id, Model model) {
	    Product existingProduct = productService.getProductById(id);
	    if (existingProduct != null) {
	        ProductDto prdtDto = new ProductDto();
	        prdtDto.setName(existingProduct.getName());
	        prdtDto.setBrands(existingProduct.getBrands());
	        prdtDto.setCategory(existingProduct.getCategory());
	        prdtDto.setPrice(existingProduct.getPrice());
	        prdtDto.setDescription(existingProduct.getDescription());
	        // Do not set the image in DTO, as it will be uploaded during the update

	        model.addAttribute("prdtDto", prdtDto);
	        model.addAttribute("productId", id); // Passing the product id to the form
	        return "products/updateProduct";
	    } else {
	        return "redirect:/products"; // Redirect if product not found
	    }
	}


	@PostMapping("/update/{id}")
	public String updateProduct(@PathVariable("id") Integer id,
	                            @Valid @ModelAttribute("prdtDto") ProductDto prdtDto,
	                            BindingResult result,
	                            @RequestParam("imageFile") MultipartFile imageFile,
	                            Model model) {
	    if (result.hasErrors()) {
	        return "products/updateProduct";
	    }

	    // Fetch existing product from database
	    Product existingProduct = productService.getProductById(id);
	    if (existingProduct != null) {
	        existingProduct.setName(prdtDto.getName());
	        existingProduct.setBrands(prdtDto.getBrands());
	        existingProduct.setCategory(prdtDto.getCategory());
	        existingProduct.setPrice(prdtDto.getPrice());
	        existingProduct.setDescription(prdtDto.getDescription());

	        // Handle the image file
	        if (!imageFile.isEmpty()) {
	            String fileName = imageFile.getOriginalFilename();
	            if (fileName != null && !fileName.isEmpty()) {
	                // Delete the old image file
	                java.nio.file.Path oldImagePath = Paths.get("public/image", existingProduct.getImageFileName());
	                try {
	                    Files.deleteIfExists(oldImagePath);
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }

	                // Save the new image file
	                java.nio.file.Path uploadPath = Paths.get("public/image");
	                try {
	                    if (!Files.exists(uploadPath)) {
	                        Files.createDirectories(uploadPath);
	                    }
	                    java.nio.file.Path filePath = uploadPath.resolve(fileName);
	                    Files.copy(imageFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
	                    existingProduct.setImageFileName(fileName); // Update with new image file name
	                } catch (IOException e) {
	                    e.printStackTrace();
	                    result.addError(new FieldError("prdtDto", "imageFile", "Failed to save the new image file"));
	                    return "products/updateProduct";
	                }
	            }
	        }

	        // Save the updated product entity
	        productService.saveProduct(existingProduct);
	        return "redirect:/products";
	    } else {
	        return "redirect:/products"; // If the product is not found, redirect to the product list
	    }
	}


}
