package com.boostmtStore.Services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.boostmtStore.models.Product;
import com.boostmtStore.models.ProductDto;

import ch.qos.logback.core.model.Model;

import com.boostmtStore.Services.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public void saveProduct(Product product) {
        productRepository.save(product);
    }
    public Product getProductById(Integer id) {
        return productRepository.findById(id).orElse(null);
    }

    public void deleteProductById(Integer productId) {
        Optional<Product> productOptional = productRepository.findById(productId);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();

            // Get the image file name
            String imageFileName = product.getImageFileName();

            // Delete the product from the database
            productRepository.delete(product);

            // Delete the image file from the file system
            if (imageFileName != null && !imageFileName.isEmpty()) {
                Path uploadPath = Paths.get("uploads/");
                Path filePath = uploadPath.resolve(imageFileName);
                try {
                    Files.deleteIfExists(filePath);
                } catch (IOException e) {
                    e.printStackTrace();
                    // Handle the exception, such as logging the error
                }
            }
        } else {
            // Handle the case where the product is not found, if necessary
            // For example, log a warning or throw a custom exception
        }
    }
  

}
