package com.boostmtStore.Services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boostmtStore.models.Product;

public interface ProductRepository extends JpaRepository<Product , Integer>{

}
