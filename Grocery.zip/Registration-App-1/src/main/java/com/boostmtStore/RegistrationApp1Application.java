package com.boostmtStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationApp1Application.class, args);
	}

}
