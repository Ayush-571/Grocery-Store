package com.boostmtStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
